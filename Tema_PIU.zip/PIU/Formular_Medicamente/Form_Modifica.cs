﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Farmacie;

namespace Formular_Medicamente
{
    public partial class Form_Modifica : Form
    {
        
        public Form1 f;
        
        public Form_Modifica()
        {
            InitializeComponent();
            Producator.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            f.Show(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int k = get_index(Denumire.Text);
            if (Producator.SelectedItem == null)
            {
                MessageBox.Show("Introduceti Producatorul!");
                Producator.BackColor = Color.Red;

            }
            else Producator.BackColor = Color.GhostWhite;
            if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == false)
            {
                MessageBox.Show("Introduceti Formatul!");
            }
            int cod, stoc;
            float pret;
            if (Cod.Text == "" || int.TryParse(Cod.Text, out cod) != true)
            {
                MessageBox.Show("Introduceti Codul/Format incorect!");
                Cod.BackColor = Color.Red;

            }
           
            else Cod.BackColor = Color.GhostWhite;
            if (Pret.Text == "" || float.TryParse(Pret.Text, out pret) != true)
            {
                MessageBox.Show("Introduceti Pretul/Format incorect!");
                Pret.BackColor = Color.Red;

            }
            else Pret.BackColor = Color.GhostWhite;
            if (Stoc.Text == "" || int.TryParse(Stoc.Text, out stoc) != true)
            {
                MessageBox.Show("Introduceti Stocul/Format incorect!");
                Stoc.BackColor = Color.Red;

            }
            else Stoc.BackColor = Color.GhostWhite;
            if ((checkBox1.Checked == false && checkBox2.Checked == false) || (checkBox1.Checked == true && checkBox2.Checked == true))
            {
                MessageBox.Show("Bifati doar o singura optiune(Mod Eliberare)!");
            }
            int _cod = 0, _stoc = 0;
            float _pret = 0;
            if (int.TryParse(Cod.Text, out _cod) == true && int.TryParse(Stoc.Text, out _stoc) == true && float.TryParse(Pret.Text, out _pret) == true && Denumire.Text != "" && Cod.Text != "" && Pret.Text != "" && Stoc.Text != "" && (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true) && (checkBox1.Checked == true && checkBox2.Checked == false) || (checkBox1.Checked == false && checkBox2.Checked == true) && Producator.SelectedItem != null)
            {
                
                f.medicamente[k].producator = Producator.SelectedItem.ToString();
                f.medicamente[k].natura = GetFormat();
                f.medicamente[k].cod = _cod;
                f.medicamente[k].pret = _pret;
                f.medicamente[k].stoc = _stoc;
                f.medicamente[k].mod_eliberare = GetEliberare();
                f.medicamente[k].dataActualizare = DateTime.Now;
               
                MessageBox.Show("Medicament modficat!");
                button2.Enabled = false;
            }
        }
        private bool validare_nume(string nume)
        {
            foreach (Medicament m in f.medicamente)
            {
                if (m.denumire.Equals(nume))
                {
                    return true;
                }
            }
            return false;
        }
        private int get_index(string nume)
        {
            foreach (Medicament m in f.medicamente)
            {
                if (m.denumire.Equals(nume))
                {
                    return f.medicamente.IndexOf(m);
                }
            }
            return 0;
        }
        private Natura GetFormat()
        {
            if (radioButton1.Checked)
                return Natura.Comprimate;
            if (radioButton2.Checked)
                return Natura.Sirop;
            if (radioButton3.Checked)
                return Natura.Gel;
            return Natura.Inexistent;
        }
        private Eliberare GetEliberare()
        {
            if (checkBox1.Checked == true && checkBox2.Checked == false)
                return Eliberare.Reteta;
            if (checkBox2.Checked == true && checkBox1.Checked == false)
                return Eliberare.Fara_reteta;
            return Eliberare.Inexistent;
        }
    }
}
