﻿using Farmacie;

using System;
using System.Collections.Generic;

namespace NivelAccesDate
{
    //clasa AdministrareStudenti_FisierBinar implementeaza interfata IStocareData
    public class AdministrareMedicamente_FisierBinar : IStocareData
    {
        string NumeFisier { get; set; }
        public AdministrareMedicamente_FisierBinar(string numeFisiser)
        {
            this.NumeFisier = NumeFisier;
        }

        public void AddMedicament(Medicament m)
        {
            throw new Exception("Optiunea AddStudent nu este implementata");
        }

        public List<Medicament> GetMedicamente()
        {
            throw new Exception("Optiunea GetMedicamente nu este implementata");
        }

        public Medicament GetMedicament(string nume)
        {
            throw new Exception("Optiunea GetMedicament nu este implementata");
        }
    }
}
