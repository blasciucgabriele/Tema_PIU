﻿using Farmacie;

using System.Collections.Generic;

namespace NivelAccesDate
{
    //definitia interfetei
    public interface IStocareData
    {
        void AddMedicament(Medicament m);
        List<Medicament> GetMedicamente();

        Medicament GetMedicament(string nume);

      
    }
}
