﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Farmacie
{
	public enum Eliberare
	{
		Inexistent = 0,
		Reteta = 1,
		Fara_reteta = 2
	};
	public enum Natura
	{
		Inexistent = 0,
		Comprimate = 1,
		Sirop = 2,
		Gel = 3,
	};
}
