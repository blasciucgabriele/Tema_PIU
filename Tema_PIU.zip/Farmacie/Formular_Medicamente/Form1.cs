﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Farmacie;

namespace Formular_Medicamente
{
    public partial class Form1 : Form
    {
        
        public List<Medicament> medicamente = new List<Medicament>();
        const int maxim = 7;
        const int mx = 15;
        public Form1()
        {  
            InitializeComponent();
            Producator.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private Natura GetFormat()
        {
            if (radioButton1.Checked)
                return Natura.Comprimate;
            if (radioButton2.Checked)
                return Natura.Sirop;
            if (radioButton3.Checked)
                return Natura.Gel;
            return Natura.Inexistent;
        }
        private Eliberare GetEliberare()
        {
            if (checkBox1.Checked==true && checkBox2.Checked==false)
                return Eliberare.Reteta;
            if (checkBox2.Checked==true && checkBox1.Checked==false)
                return Eliberare.Fara_reteta;
            return Eliberare.Inexistent;
        }


        private bool validare_nume(string nume)
        {
            foreach (Medicament m in medicamente)
            {
                if (m.denumire.Equals(nume))
                {
                    return true;
                }
            }
            return false;
        }
        private int get_index(string nume)
        {
            for (int i = 0; i <medicamente.Count(); i++)
            {
                if (nume == medicamente[i].denumire)
                {
                    return i;
                }
            }
            return -1;
        }
       
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            if (Denumire.Text == "" || Denumire.Text.Length>mx)
            {
                MessageBox.Show("Introduceti Denumirea!");
                Denumire.BackColor = Color.Red;

            }
            else Denumire.BackColor = Color.GhostWhite;
            if (Producator.SelectedItem==null)
            {
                MessageBox.Show("Introduceti Producatorul!");
                Producator.BackColor = Color.Red;

            }
            else Producator.BackColor = Color.GhostWhite;
            if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == false)
            {
                MessageBox.Show("Introduceti Formatul!");
            }
            int cod, stoc;
            float pret;
            if (Cod.Text == "" || int.TryParse(Cod.Text, out cod) != true || Cod.Text.Length > maxim)
            {
                MessageBox.Show("Introduceti Codul/Format incorect!");
                Cod.BackColor = Color.Red;

            }
            else Cod.BackColor = Color.GhostWhite;
            if (Pret.Text == "" || float.TryParse(Pret.Text, out pret) != true || Pret.Text.Length>maxim)
            {
                MessageBox.Show("Introduceti Pretul/Format incorect!");
                Pret.BackColor = Color.Red;

            }
            else Pret.BackColor = Color.GhostWhite;
            if (Stoc.Text == "" || int.TryParse(Stoc.Text, out stoc) != true || Stoc.Text.Length>maxim)
            {
                MessageBox.Show("Introduceti Stocul/Format incorect!");
                Stoc.BackColor = Color.Red;

            }
            else Stoc.BackColor = Color.GhostWhite;
            if ((checkBox1.Checked == false && checkBox2.Checked == false) || (checkBox1.Checked == true && checkBox2.Checked == true))
            {
                MessageBox.Show("Bifati doar o singura optiune(Mod Eliberare)!");
            }

            int _cod = 0, _stoc = 0;
            float _pret=0;
            if (int.TryParse(Cod.Text, out _cod) == true && int.TryParse(Stoc.Text, out _stoc) == true && float.TryParse(Pret.Text, out _pret) == true && Denumire.Text != "" && Cod.Text != "" && Pret.Text != "" && Stoc.Text != "" && (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true) && (checkBox1.Checked == true && checkBox2.Checked == false) || (checkBox1.Checked == false && checkBox2.Checked == true) && Producator.SelectedItem!=null)
            {
                
                    Medicament m = new Medicament(Denumire.Text, Producator.SelectedItem.ToString(), Convert.ToString(GetFormat()), _cod, _pret,_stoc, Convert.ToString(GetEliberare()));
                    medicamente.Add(m);
                    m.Add_Medicament();
               
                

                    MessageBox.Show("Medicament adaugat!");
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Items.Clear();
            var j = String.Format("{0,-5}{1,-15}{2,-20}{3,-15}{4,-12}{5,-10}{6,-10}{7,-20}\n", "Id", "Denumire", "Producator", "Format", "Cod", "Pret", "Stoc", "Mod Eliberare");
            richTextBox1.Items.Add(j);
            if (medicamente.Count() == 0) MessageBox.Show("Nu exista produse!");
            else
            {
                int c = 1;
                richTextBox1.ForeColor = Color.Black;
                if (checkBox1.Checked == true || checkBox2.Checked == true)
                {
                    foreach (Medicament m in medicamente)
                    {
                        var k = String.Format("{0,-5}{1,-15}{2,-20}{3,-15}{4,-12}{5,-10}{6,-10}{7,-20}\n", c, m.denumire, m.producator, Convert.ToString(m.n), m.cod, m.pret, m.stoc, m.el.ToString());
                        richTextBox1.Items.Add(k);
                        c = c + 1;
                    }
                }
                if (checkBox1.Checked == true && checkBox2.Checked == true)
                    MessageBox.Show("Bifati doar o optiune!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            Denumire.Text = Producator.Text = Cod.Text = Pret.Text = Stoc.Text = "";
            richTextBox1.Items.Clear();
            Producator.SelectedIndex = -1;
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Blasciuc Gabriele-Andrea, 3124a, FIESC C2");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            richTextBox1.Items.Clear();
            if (Denumire.Text == "")
            {
                MessageBox.Show("Introduceti denumirea!");
                Denumire.BackColor = Color.Red;
            }
            else
            {
                Denumire.BackColor = Color.GhostWhite;
                foreach (Medicament m in medicamente)
                {
                    if (m.denumire.Equals(Denumire.Text) == true)
                    {
                        richTextBox1.ForeColor = Color.Green;
                        richTextBox1.Items.Clear();
                        richTextBox1.Items.Add("Produsul exista!");
                    }
                    else
                    {
                        richTextBox1.Items.Clear();
                        richTextBox1.ForeColor = Color.Red;
                        richTextBox1.Items.Add("Produsul nu exista");
                    }
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (medicamente.Count() == 0)  MessageBox.Show("Nu exista medicamente!");
            else
            {
                if (Denumire.Text == "")
                {
                    MessageBox.Show("Introduceti Denumirea!");
                    Denumire.BackColor = Color.Red;
                }
                else Denumire.BackColor = Color.GhostWhite;
                foreach (Medicament m in medicamente)
                {
                    if (m.denumire.Equals(Denumire.Text) == true)
                    {
                        Form_Modifica f = new Form_Modifica();
                        f.f = this;
                        f.ShowDialog();
                    }
                    else if (m.denumire.Equals(Denumire.Text) == false)
                        MessageBox.Show("Medicamentul nu exista!");
                }
            }
        }
       
                          
        }
       
    }
   

